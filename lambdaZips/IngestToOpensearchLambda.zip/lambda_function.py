import json
import boto3
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client

url = 'https://ac8cf13248c104ed79faaf91239faf31-9e9903eb569f79a2.elb.us-east-1.amazonaws.com:9200/unified-search/'

# Lambda excution starts here  

def lambda_handler(event, context):
    headers = { "Content-Type": "application/json" }
    
    print('### Prepping BULK')
    payload_body = json.loads(event.get('body'))
    uploadCount = 0
    bulk_payload = ""
    
    for document in payload_body.get('documents'):
        bulk_payload = bulk_payload + json.dumps({ "index": { "_id": document.get('id') } }) + "\n"
        bulk_payload = bulk_payload + json.dumps(document) + "\n"
        uploadCount = uploadCount + 1
    
    print('### POSTING BULK UPDATE')
    print(bulk_payload)
    bulk_request=requests.post(url + '_bulk', 
            data=bulk_payload,
            headers=headers, 
            verify=False, 
            auth = HTTPBasicAuth('admin', 'admin'),
            timeout=180)
    print(bulk_request.content)

    response = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": '*'
        },
        "isBase64Encoded": False,
        "body": bulk_request.content
    }
    return response
   