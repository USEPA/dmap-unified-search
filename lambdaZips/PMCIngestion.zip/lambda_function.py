import json
import boto3
import requests
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
import os

API_ENDPOINT = os.environ['API_ENDPOINT']
X_API_KEY = os.environ['X_API_KEY']




# Last element in dates array is published

headers = { "Content-Type": "application/json" }
url = 'https://www.ncbi.nlm.nih.gov/pmc/oai/oai.cgi?verb=ListRecords'
lookup_params = '&=ListRecords&from=2019-01-01&until=2022-12-12&set=epapa&metadataPrefix=oai_dc'
payload_for_unified_search = { "documents": []}
ingested_records = []
failed_records = []
responses = []


def lambda_handler(event, context):
    next_url = None
    count = 0
    while count < 100:
        #Reset documents in payload
        payload_for_unified_search["documents"] = []
        resumption_token = request_data_from_pmc(next_url or url + lookup_params)
        response = upload_data_to_opensearch(payload_for_unified_search)
        responses.append(response.content)
        if resumption_token is not None:
            next_url = url + "&resumptionToken=" + resumption_token
        else:
            break
        count = count + 1
    combined_response = {
        "failed_records": failed_records,
        "ingested_records": ingested_records,
        "responses": responses
    }
    return payload_for_unified_search


def request_data_from_pmc(url):
    pmc_xml_response = requests.get(url, timeout=240, headers=headers)
    xml = ET.XML(pmc_xml_response.content)
    pmc_dict = etree_to_dict(xml)
    list_of_records = pmc_dict["{http://www.openarchives.org/OAI/2.0/}OAI-PMH"]["{http://www.openarchives.org/OAI/2.0/}ListRecords"]
    if "{http://www.openarchives.org/OAI/2.0/}resumptionToken" in list_of_records:
        resumption_token = list_of_records["{http://www.openarchives.org/OAI/2.0/}resumptionToken"]
    else:
        resumption_token = None
    for record in list_of_records["{http://www.openarchives.org/OAI/2.0/}record"]:
        metadata = record["{http://www.openarchives.org/OAI/2.0/}metadata"]
        dc = metadata["{http://www.openarchives.org/OAI/2.0/oai_dc/}dc"]
        try:
            date = dc["{http://purl.org/dc/elements/1.1/}date"]
            if isinstance(date, list):
                date_value = date[-1]
            else:
                date_value = date
            date_object = {
                "date": date_value,
                "title": "Published"
            }
            parsed_description = re.sub(r'<.*?>', '', dc["{http://purl.org/dc/elements/1.1/}description"])
            parsed_title = re.sub(r'<.*?>', '', dc["{http://purl.org/dc/elements/1.1/}title"])
            identifiers = dc["{http://purl.org/dc/elements/1.1/}identifier"]
            doi = None
            if identifiers is not None:
                doi = identifiers[2].split(".org/")[1]
                print("DOI: " + doi)
        
            pmc_url_id_string = identifiers[0]
            lead_author_name = dc["{http://purl.org/dc/elements/1.1/}creator"][0]
            co_authors = dc["{http://purl.org/dc/elements/1.1/}creator"][1:]

            record_for_unified_search = {
                "title": parsed_title,
                "description": parsed_description or "",
                "record_type": "Journal Article",
                "id": pmc_url_id_string,
                "source": "PMC",
                "organization": "US EPA",
                "doi": doi,
                "lead": lead_author_name,
                "lead_keyword": lead_author_name,
                "date": date_object,
                "co_authors": co_authors,
                "co_authors_keyword": co_authors,
                "url": "https://www.ncbi.nlm.nih.gov/" + pmc_url_id_string
            }
            payload_for_unified_search['documents'].append(record_for_unified_search)
            ingested_records.append(dc)
        except Exception as e:
            failed_records.append(dc)
    return resumption_token


def retreive_lead_author(record):
    lead_author = None
    contributors = record.get("contributors")
    authors = contributors.get("authors")
    for author in authors:
        if author.get('rank') == 1:
            # Found lead author
            lead_author = author
            break
    return lead_author

def upload_data_to_opensearch(json_request):
    auth_headers = {'content-type': 'application/json', 'x-api-key': X_API_KEY, 'Accept': 'application/json'}
    r = requests.put(API_ENDPOINT, headers=auth_headers, timeout=15, json=json_request)
    return r



def etree_to_dict(t):
    d = {t.tag: {} if t.attrib else None}
    children = list(t)
    if children:
        dd = defaultdict(list)
        for dc in map(etree_to_dict, children):
            for k, v in dc.items():
                dd[k].append(v)
        d = {t.tag: {k: v[0] if len(v) == 1 else v
                     for k, v in dd.items()}}
    if t.attrib:
        d[t.tag].update(('@' + k, v)
                        for k, v in t.attrib.items())
    if t.text:
        text = t.text.strip()
        if children or t.attrib:
            if text:
                d[t.tag]['#text'] = text
        else:
            d[t.tag] = text
    return d

def parse_date(article_meta):
    date_object = {
        "date": None,
        "title": None
    }
    pub_dates = article_meta["{https://jats.nlm.nih.gov/ns/archiving/1.3/}pub-date"]
    for pub_date in pub_dates:
        if pub_date["@pub-type"] == "pmc-release":
            date_object["title"] = "Published"
            date_object["date"] = pub_date["{https://jats.nlm.nih.gov/ns/archiving/1.3/}year"] + "-" + pub_date["{https://jats.nlm.nih.gov/ns/archiving/1.3/}month"].zfill(2) + "-" + pub_date["{https://jats.nlm.nih.gov/ns/archiving/1.3/}day"].zfill(2)
    return date_object

def parse_ids(id_sets):
    parsed_ids = {"doi": None, "pmc": None}
    for id_set in id_sets:
        if id_set["@pub-id-type"] == "doi":
            parsed_ids["doi"] = id_set["#text"]
        if id_set["@pub-id-type"] == "pmcid":
            parsed_ids["pmc"] = id_set["#text"]
    return parsed_ids

def parse_author_from_contribs(contribs):
    for contrib in contribs:
        if contrib["@contrib-type"] == "author":
            name = contrib["{https://jats.nlm.nih.gov/ns/archiving/1.3/}name"]
            first_name = name["{https://jats.nlm.nih.gov/ns/archiving/1.3/}given-names"]
            last_name = name["{https://jats.nlm.nih.gov/ns/archiving/1.3/}surname"]
            break
    return last_name + ", " + first_name

def pmc_format(event, context):

    #Send mock data first
    pmc_xml_response = requests.get('https://www.ncbi.nlm.nih.gov/pmc/oai/oai.cgi?verb=ListRecords&from=2022-01-01&until=2023-01-01&set=epapa&metadataPrefix=pmc_fm', timeout=120, headers=headers)
    xml = ET.XML(pmc_xml_response.content)
    pmc_dict = etree_to_dict(xml)
    payload_for_unified_search = { "documents": []}
    for record in pmc_dict["{http://www.openarchives.org/OAI/2.0/}OAI-PMH"]["{http://www.openarchives.org/OAI/2.0/}ListRecords"]["{http://www.openarchives.org/OAI/2.0/}record"]:
        metadata = record["{http://www.openarchives.org/OAI/2.0/}metadata"]
        article = metadata["{https://jats.nlm.nih.gov/ns/archiving/1.3/}article"]
        front= article["{https://jats.nlm.nih.gov/ns/archiving/1.3/}front"]
        article_meta = front["{https://jats.nlm.nih.gov/ns/archiving/1.3/}article-meta"]
        id_sets = article_meta["{https://jats.nlm.nih.gov/ns/archiving/1.3/}article-id"]
        contribs = article_meta["{https://jats.nlm.nih.gov/ns/archiving/1.3/}contrib-group"]["{https://jats.nlm.nih.gov/ns/archiving/1.3/}contrib"]
        try:
            date_object = parse_date(article_meta)
            abstract = article_meta["{https://jats.nlm.nih.gov/ns/archiving/1.3/}abstract"]["{https://jats.nlm.nih.gov/ns/archiving/1.3/}p"]["#text"]
            parsed_description = re.sub(r'<.*?>', '', abstract)
            parsed_title = re.sub(r'<.*?>', '', article_meta["{https://jats.nlm.nih.gov/ns/archiving/1.3/}title-group"]["{https://jats.nlm.nih.gov/ns/archiving/1.3/}article-title"])
            parsed_ids = parse_ids(id_sets)
            lead_author_name = parse_author_from_contribs(contribs)
            record_for_unified_search = {
                "title": parsed_title,
                "description": parsed_description or "",
                "record_type": "Journal",
                "id": parsed_ids["pmc"],
                "source": 'PMC',
                "subtype": "Article",
                "organization": "US EPA",
                "doi": parsed_ids["doi"] or "",
                "lead": lead_author_name,
                "lead_keyword": lead_author_name,
                "date": date_object
            }
            payload_for_unified_search['documents'].append(record_for_unified_search)

            print("Success")
        except Exception as e:
            failed_records.append(article_meta)
            print(e)
            print("Error")


    #     except:
    #         print("Unable to initialize document for Record: " + str(record.get('id')) + " (" + record.get('title') + ")")
    # print(payload_for_unified_search)
    response = upload_data_to_opensearch(payload_for_unified_search)
    combined_response = {
        "content": {
            "real": response.content
        }
    }
    return combined_response