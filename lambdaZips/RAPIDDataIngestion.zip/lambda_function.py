import json
import boto3
import requests
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client
import re
import os

API_ENDPOINT = os.environ['API_ENDPOINT']
X_API_KEY = os.environ['X_API_KEY']
RAPID_ENDPOINT = os.environ['RAPID_ENDPOINT']
GENERATE_TOKEN_PARAMS = os.environ['GENERATE_TOKEN_PARAMS']

headers = { "Content-Type": "application/json" }

mock_data = {
  "documents": [
    {
      "title": "Climate-change refugia: biodiversity in the slow lane",
      "record_type": "Journal Article",
      "id": 111,
      "source": "RAPID",
      "lead": "Matkin, Benjamin",
      "lead_keyword": "Matkin, Benjamin",
      "organization": "ORD",
      "description": "Human-caused climate change will rapidly alter ecosystems around the globe, putting species that inhabit them under severe stress. These sweeping ecological changes will leave little time for species and ecosystems to adapt to new conditions, resulting in extinctions and large-scale ecosystem transformations. In a time of dramatic ecological upheaval, identifying and protecting climate change refugia -- areas relatively buffered from climate change over time -- can protect species from the negative effects of climate change in the short-term as well as provide longer-term protection for biodiversity and ecosystem function.",
      "subtype": "Peer Reviewed",
      "scid": "FAKE-01",
      "doi": "10.1002/fee.2189",
      "doi_parts": {
        "organization": "10.1002",
        "record": "fee.2189"
      },
      "date": {
        "title": "Published",
        "date": "1990-02-02"
      }
    },
    {
      "title": "Solutions to Climate Change - Mock",
      "record_type": "Sub-Product",
      "id": 211,
      "source": "RAPID",
      "lead": "Cavatelli, Brenda",
      "lead_keyword": "Cavatelli, Brenda",
      "organization": "ORD",
      "description": "Everyone can help limit climate change. From the way we travel, to the electricity we use and the food we eat, we can make a difference. Start with these ten actions to help tackle the climate crisis.",
      "subtype": "Model",
            "scid": "FAKE-02",
      "date": {
        "title": "Published",
        "date": "2021-04-20"
      }
    },
    {
      "title": "Responding to Climate Change Impacts - Mock",
      "record_type": "Sub-Product",
      "id": 311,
      "source": "RAPID",
      "lead": "Garganelli, Calvin",
      "lead_keyword": "Garganelli, Calvin",
      "organization": "ORD",
      "description": "Responding to climate change involves two possible approaches: reducing and stabilizing the levels of heat-trapping greenhouse gases in the atmosphere (“mitigation”) and adapting to the climate change already in the pipeline (“adaptation”).",
      "subtype": "Model",
            "scid": "FAKE-03",
      "date": {
        "title": "Published",
        "date": "1999-01-01"
      }
    },
    {
      "title": "Air Quality Challenges due to Climate Change - Mock",
      "record_type": "Sub-Product",
      "id": 411,
      "source": "RAPID",
      "lead": "Pappardelle, Donna",
      "lead_keyword": "Pappardelle, Donna",
      "organization": "ORD",
      "description": "Climate change creates conditions, including heat and stagnant air, which increase the risk of unhealthful ozone levels. Ground-level ozone, often called smog, forms in the atmosphere when gases emitted from smokestacks and tailpipes mix in the air.",
      "subtype": "Model",
            "scid": "FAKE-04",
      "date": {
        "title": "Cleared",
        "date": "1999-01-01"
      }
    },
    {
      "title": "Climate Change Intervention Strategies - Mock",
      "record_type": "Sub-Product",
      "id": 411,
      "source": "RAPID",
      "lead": "Pappardelle, Donna",
      "lead_keyword": "Pappardelle, Donna",
      "organization": "ORD",
      "description": "The two main options for responding to the risks of climate change involve mitigation—reducing and eventually eliminating human-caused emissions of CO2 and other greenhouse gases (GHGs)—and adaptation—reducing the vulnerability of human and natural systems to changes in climate.",
      "subtype": "Model",
            "scid": "FAKE-05",
      "date": {
        "title": "Cleared",
        "date": "1999-01-01"
      }
    }
  ]
}


def lambda_handler(event, context):
    #Send mock data first
    mock_response = upload_data_to_opensearch(mock_data)
    print(mock_response.content)
    token_json = authenticate_request()
    token = json.loads(token_json).get('accessToken')
    headers["Authorization"] = "Bearer " + token
    rapidData = requests.get(RAPID_ENDPOINT + '/rapid-integration/api/v2/sub-products?skip=0&top=1000', timeout=30, headers=headers)
    print("############RAPID DATA")
    print(rapidData.content)
    return rapidData.content
    payload_for_unified_search = { "documents": []}
    for record in json.loads(rapidData.content).get("resources"):
        date_object = None
        if record.get("clearedDate") is not None:
              date_object = {
                date: record.get("clearedDate"),
                title: "Cleared"
            }
        if record.get("published_date") is not None:
            date_object = {
                date: record.get("publishedDate"),
                title: "Published"
            }
        parsedHTML = re.sub(r'<.*?>', '', record.get("description"))
        record_for_unified_search = {
            "title": record.get('title'), 
            "description": parsedHTML or "", 
            "record_type": record.get("type") or "", 
            "id": record.get('id'), 
            "source": "RAPID" or "",
            "subtype": record.get("subtype") or "",
            "organization": record.get("subProductLead").get("orgCode"),
            "lead": record.get("subProductLead").get("lastName") + ", " + record.get("subProductLead").get("firstName"),
            "lead_keyword": record.get("subProductLead").get("lastName") + ", " + record.get("subProductLead").get("firstName"),
            "date": date_object,
            "scid": record.get("scid")
        }
        payload_for_unified_search['documents'].append(record_for_unified_search)
    response = upload_data_to_opensearch(payload_for_unified_search)
    combined_response = {
      "content": {
        "data_ingested_source": rapidData.content,
        "mock": mock_response.content,
        "real": response.content
      }
    }
    return combined_response

def authenticate_request():
    tokenRequest = requests.get(RAPID_ENDPOINT + '/rapid-integration/api/v2/authentication/generate-token?' + GENERATE_TOKEN_PARAMS, 
        timeout=5, 
        headers=headers,
        auth=("USEPA/ORD/STICS", "stics")
        )
    return tokenRequest.content
  
def upload_data_to_opensearch(json_request):
    auth_headers = {'content-type': 'application/json', 'x-api-key': X_API_KEY, 'Accept': 'application/json'}
    r = requests.put(API_ENDPOINT, headers=auth_headers, timeout=15, json=json_request)
    return r