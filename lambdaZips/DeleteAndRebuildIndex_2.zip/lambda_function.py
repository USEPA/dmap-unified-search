import json
import boto3
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client
import os

opensearch_endpoint = "https://" + os.environ['API_ENDPOINT'] + "/unified-search/"
delete_by_query_url = 'https://ac641f6747af848a3970c3a33759965e-376585678.us-east-1.elb.amazonaws.com:9200/unified-search/_delete_by_query'

mapping = {
    "mappings" : {
      "properties" : {
        "date" : {
            "properties": {
                "title": {"type": "keyword"},
                "date": {"type": "date"}
            }
        },
        "title": {"type": "text", "analyzer": "english"},
        "description": {"type": "text", "analyzer": "english"},
        "doi": {"type": "text"},
        "doi_parts": {
            "properties": {
                "organization": {"type": "keyword"},
                "record": {"type": "keyword"}
            }
         },
         "co_authors": {"type": "text"},
         "co_authors_keyword": {"type": "keyword"},
        "lead": {"type": "text"},
        "lead_keyword": {"type": "keyword"},
        "id": {"type": "text"},
        "organization": {"type": "keyword"},
        "record_type": {"type": "keyword"},
        "source": {"type": "keyword"},
        "subtype": {"type": "keyword"},
        "url": {"type": "text"}
        }
      }
    }

delete_by_query = {
  "query": {
    "match": {
      "source": "ScienceHub"
    }
  }
}


def query_lambda_handler(event, context):
    headers = { "Content-Type": "application/json" }
     
    #Delete Index before update
    try:
        delete = requests.post(delete_by_query_url,
            headers=headers, 
            auth = HTTPBasicAuth('admin', 'admin'),
            timeout=5,
            data=json.dumps(delete_by_query))
        print('### DELETING data')
        print(delete.content)
    except Exception as e:
        print(e)
        print("Unable to delete by query")
        


# Lambda excution starts here  
def lambda_handler(event, context):
    headers = { "Content-Type": "application/json" }
     
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, 'us-east-1', service, session_token=credentials.token)

    #Delete Index before update
    try:
        delete = requests.delete(opensearch_endpoint,
            headers=headers, 
            verify=False, 
            auth = awsauth,
            timeout=3)
        print('### DELETING INDEX')
        print(delete.content)
    except Exception as e:
        print(e)
        print("Unable to delete index, possibly already deleted")
        
    #Create Index before update
    try:
        create = requests.put(opensearch_endpoint,
            headers=headers, 
            auth = awsauth,
            timeout=5, json=mapping )          
        print('### CREATING INDEX')
        print(create.content)    
    except Exception as e:
        print(e)
        print("Unable to create index")

   