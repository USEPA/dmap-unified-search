import json
import boto3
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
import re

STRIP_HTML = re.compile('<.*?>') 
endpoint = 'http://a6cabd79e82a54135b17ffa0e72ffc08-2060953647.us-east-1.elb.amazonaws.com:9200/unified_search'


host = 'https://ac8cf13248c104ed79faaf91239faf31-9e9903eb569f79a2.elb.us-east-1.amazonaws.com:9200/unified-search'
index = 'unified-search'
url = host + '/_search'

DESCRIPTION_MAX_LEN=425
 
response = {
    "statusCode": 200,
    "headers": {
        "Access-Control-Allow-Origin": '*'
    },
    "isBase64Encoded": False

}

# Lambda excution starts here  

def lambda_handler(event, context): 
    try:
      search_term = event["queryStringParameters"]['term']
    except:
      search_term = "Certified Commercial Water"
      
    fuzziness = "AUTO"
    

        
    try:
      page = event["queryStringParameters"]['page']
    except:
      page = 1
        
    try:
      size = event["queryStringParameters"]['size']
    except:
      size = 10
      
    association_size = size
        
    
    #See https://opensearch.org/docs/2.3/opensearch/search/paginate
    from_amount = int(size) * (int(page) - 1)
    print("##### PAGE")
    print(page)
    print("##### SIZE")
    print(size)
    print("#### FROM")
    print(from_amount)
    
    try:
      payload_body = json.loads(event.get('body'))
      filters = payload_body.get("filters")
    except:
      print("Filters not passed in payload")
      filters = []

    print("#########SearchTerm")
    print(search_term)
    print("#########Filters")
    print(filters)

    opensearchFilters = []
    additionalSearchCriteria = None
    for filter in filters:
      if filter.get("filterName") == "year":
        opensearchTermFilter = create_range_filter(filter.get("filterValue"))
      elif filter.get("filterName") == "co_authors":
        additionalSearchCriteria = {"match": 
            {filter.get("filterName"): 
              { "query": filter.get("filterValue")}
            }
          }
        continue
      else:
        opensearchTermFilter = {"term": {filter.get("filterName"): filter.get("filterValue")}}
      opensearchFilters.append(opensearchTermFilter)
    


    # Put the user query into the query DSL for more accurate search results.
    query = {
    "from": str(from_amount),
    "size": str(association_size),
    "highlight": {
      "fields": {
        "*": {
          "pre_tags": "<em class='highlight'>",
          "post_tags": "</em>",
          "fragment_size": 200
        }
        }
    },
    "query": {
      "bool": {
        "must": [
        ],
        "filter": opensearchFilters
      }
    },
    "aggs": {
      "date-bucket": {
        "date_histogram": {
          "field": "date.date",
          "calendar_interval": "year"
        }
      },
      "source-bucket": {
        "terms": {
          "field": "source"
        }
      },
      "org-bucket": {
        "terms": {
          "field": "organization"
        }
      },
      "lead-author-bucket": {
        "terms": {
          "field": "lead_keyword"
        }
      },
      "record-type-bucket": {
        "terms": {
          "field": "record_type"
        }
      },
      "subtype-bucket": {
        "terms": {
          "field": "subtype"
        }
      }
    }
  }
  
    if (search_term != ''):
       query["query"]["bool"]["must"].append(
         { "multi_match": {
            "fields": [
              "title", "description", "record_type", "source", "subtype", "organization", "doi_parts.*", "lead", "co_authors"
            ],
            "analyzer": "english",
            "query": search_term
          } }
         )
    if (additionalSearchCriteria is not None):
      query["query"]["bool"]["must"].append(additionalSearchCriteria)
    

      # ES 6.x requires an explicit Content-Type header
    headers = { "Content-Type": "application/json" }

    # Make the signed HTTP request
    r  = requests.get(url, headers=headers, verify=False, auth = HTTPBasicAuth('admin', 'admin'), json=query)
    search_results = json.loads(r.text)
    search_results["hits"]["hits"] = apply_highlights(search_results)
    search_results = remove_empty_subtype_bucket(search_results)
    search_results = develop_associations(search_results)

    
    # Add the search results to the response
    response['body'] = json.dumps(search_results)
    return response
    
def create_range_filter(filter_value):
  start_year = str(int(filter_value) - 1)
  range_filter = {
    "range": {
      "date.date": {
        "gt": start_year + "-12-31",
        "lte": filter_value + "-12-31",
        "format": "yyyy-MM-dd"
      }
    }
  }
  print("#RANGE FILTER")
  print(range_filter)
  return range_filter

def apply_highlights(search_results):
  ALLOWED_HIGHLIGHTS = ["description", "title", "co_authors"]
  try:
    parsed_hits = search_results["hits"]["hits"]
    for i in range(len(parsed_hits)):
      if "_source" in parsed_hits[i]:
        if "highlight" in parsed_hits[i]:
          for highlighted_key in parsed_hits[i]["highlight"]:
            if highlighted_key in ALLOWED_HIGHLIGHTS:
              parsed_hits[i]["_source"][highlighted_key] = ' ... '.join(parsed_hits[i]["highlight"][highlighted_key])
          if "co_authors" not in parsed_hits[i]["highlight"] and "co_authors" in parsed_hits[i]["_source"]:
            #Remove co_authors from results if not highlighted
            del(parsed_hits[i]["_source"]["co_authors"])
        if "description" in parsed_hits[i]["_source"]:
          max_range = len(parsed_hits[i]["_source"]["description"]) - 1
          if max_range < DESCRIPTION_MAX_LEN:
            parsed_hits[i]["_source"]["description"] = parsed_hits[i]["_source"]["description"][0:max_range] + "..."
          else:
            parsed_hits[i]["_source"]["description"] = parsed_hits[i]["_source"]["description"][0:DESCRIPTION_MAX_LEN] + "..."
        if "subtype" in parsed_hits[i]["_source"]:
          if parsed_hits[i]["_source"]["subtype"] == "":
             parsed_hits[i]["_source"]["subtype"] = "N/A"
        if "highlight" not in parsed_hits[i]:
          #Remove co_authors from results if not highlighted
          del(parsed_hits[i]["_source"]["co_authors"])
        if "co_authors" in parsed_hits[i]["_source"] and not isinstance(parsed_hits[i]["_source"]["co_authors"], list):
          #Fix string into array for single co_authors
          parsed_hits[i]["_source"]["co_authors"] = [parsed_hits[i]["_source"]["co_authors"]]

        
          
  except:
    parsed_hits = []
  return parsed_hits

def cleanhtml(raw_html):
  cleantext = re.sub(STRIP_HTML, '', raw_html)
  return cleantext
  
def remove_empty_subtype_bucket(search_results):
  aggregations = search_results["aggregations"]
  if "subtype-bucket" in aggregations:
    if "buckets" in aggregations["subtype-bucket"]:
      for ind, elem in enumerate(aggregations["subtype-bucket"]["buckets"]):
        if elem["key"] == "":
          search_results["aggregations"]["subtype-bucket"]["buckets"].pop(ind)
  return search_results


def develop_associations(search_results):
  ### Make array dictionaries for mapping types. Create array list.
  ### If association matches another DOI, combine
  ### If association matches another PMCID, combine
  ### If association matches another SCID combine
  ### Add to associations array in order of relevance. Capping off at 100 sized window.
  
  #Generate all mappings.
  doi_mapping = {}
  pmc_id_mapping = {}
  sc_id_mapping = {}
  
  #Loop through and fill all mappings. If first time existing, create new array with record. Otherwise append.
  associated_hits = search_results["hits"]["hits"]
  for ind, hit in enumerate(associated_hits):
    if "doi" in hit["_source"] and hit["_source"]["doi"] != '':
      if hit["_source"]["doi"].lower() not in doi_mapping:
        doi_mapping[hit["_source"]["doi"].lower()] = []
      else:
        doi_mapping[hit["_source"]["doi"].lower()].append(hit["_source"])
    if "pmcid" in hit["_source"] and hit["_source"]["pmcid"] != '':
      if hit["_source"]["pmcid"] not in pmc_id_mapping:
        pmc_id_mapping[hit["_source"]["pmcid"]] = []
      else:
        pmc_id_mapping[hit["_source"]["pmcid"]].append(hit["_source"])
    if "scid" in hit["_source"] and hit["_source"]["scid"] != '':
      if hit["_source"]["scid"] not in sc_id_mapping:
        sc_id_mapping[hit["_source"]["scid"]] = []
      else:
        sc_id_mapping[hit["_source"]["scid"]].append(hit["_source"])
  
  #Loop through records, checking each mapping. If connects, pull mapping into record, and delete mapping
  #For first record found, do not add to mapping. It is the root, mose relevant record. All subsequent are associations
  #Remove the associated record from hits so it only shows up in associations
  # Do not add blank keys
  hit_ids_to_remove = []
  for ind, hit in enumerate(associated_hits):
    if "doi" in hit["_source"]:
      if hit["_source"]["doi"].lower() in doi_mapping:
        for associated_record in doi_mapping[hit["_source"]["doi"].lower()]:
          hit_ids_to_remove.append(associated_record["id"])
        associated_hits[ind]["associations"] = doi_mapping.pop(hit["_source"]["doi"].lower())
    if "pmcid" in hit["_source"]:
      if hit["_source"]["pmcid"] in pmc_id_mapping:
        associated_hits[ind]["associations"] = pmc_id_mapping.pop(hit["_source"]["pmcid"])
    if "scid" in hit["_source"]:
      if hit["_source"]["scid"] in pmc_id_mapping:
        if len(sc_id_mapping[hit["_source"]["scid"]]) > 1:
          associated_hits[ind]["associations"] = sc_id_mapping.pop(hit["_source"]["scid"])
  unique_hit_ids_to_remove = list(set(hit_ids_to_remove))
  for ind, hit in enumerate(associated_hits):
    if hit["_source"]["id"] in unique_hit_ids_to_remove:
      associated_hits.pop(ind)
      print("REMOVING IND= " + str(hit["_source"]["id"]))
  search_results["hits"]["hits"] = associated_hits
  print("IDS TO REMOVE")
  print(unique_hit_ids_to_remove)
  
  ## Remove the ids that have been associated to avoid duplicate records
  return search_results