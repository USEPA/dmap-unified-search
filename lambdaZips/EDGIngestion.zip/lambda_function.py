import json
import boto3
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client
import datetime
from dateutil.parser import parse
import os

API_ENDPOINT = os.environ['API_ENDPOINT']
X_API_KEY = os.environ['X_API_KEY']


headers = { "Content-Type": "application/json" }

def lambda_handler(event, context):
    datasetData = requests.get('https://edg.epa.gov/metadata/rest/find/document?f=dcat&max=500', timeout=60, headers=headers)
    payload_for_unified_search = { "documents": []}
    dataset = json.loads(datasetData.content)['dataset']
    
    for record in dataset:
        doi = ""
        doi_parts = {
              "organization": None,
              "record": None
            }
        if 'identifier' in record:
          if 'doi' in record.get('identifier'):
            doi = record.get('identifier').split(".org/")[1]
            print("DOI: " + doi)
            print(doi.split('/'))
            # doi_parts['organization'] = doi.split('/')[0]
            # doi_parts.get('record') = doi.split('/')[1]
            doi_parts = {
              "organization": doi.split('/')[0],
              "record": doi.split('/')[1]
            }
        lead_name_array = record.get("contactPoint").get("fn").split(' ')
        if len(lead_name_array) > 1:
          lead_name = lead_name_array[1] + ', ' + lead_name_array[0]
        else:
          lead_name = record.get("contactPoint").get("fn")
        record_for_unified_search = {
            "title": record['title']  or "", 
            "record_type": "Dataset" or "", 
            "id": record.get('identifier') or "", 
            "source": "EDG" or "", 
            "doi": doi,
            "lead": lead_name,
            "lead_keyword": lead_name,
            "organization": "US EPA",
            "subtype": "Dataset",
            "doi_parts": doi_parts,
            "date": {
              "title": "Issued",
              "date": record.get("issued")
            },
            "url": record.get("landingPage"),
            "description": record.get("description")
        }
        payload_for_unified_search['documents'].append(record_for_unified_search)
    response = upload_data_to_opensearch(payload_for_unified_search)
    combined_response =  {
      "real_response": response.content
      }
    return combined_response


  
def upload_data_to_opensearch(json_request):
    auth_headers = {'content-type': 'application/json', 'x-api-key': X_API_KEY, 'Accept': 'application/json'}
    r = requests.put(API_ENDPOINT, headers=auth_headers, timeout=15, json=json_request)
    return r