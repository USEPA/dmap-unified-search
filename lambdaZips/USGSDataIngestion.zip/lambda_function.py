import json
import boto3
import requests
from requests.auth import HTTPBasicAuth
from getpass import getpass
import http.client
import re
import math
import os

headers = { "Content-Type": "application/json" }
PAGE_SIZE = 1500
API_ENDPOINT = os.environ['API_ENDPOINT']
X_API_KEY = os.environ['X_API_KEY']

## Editors display the same in application as authors with no distinction
## Articles without editors or authors are ignored
## Articles without subtypes are allowed


def lambda_handler(event, content):
    pulling_data = True
    response = []
    page_number = 5
    total_pages = 6
    current_response = {}
    try:
        while(page_number <= total_pages):
            current_response = usgs_data_pull(page_number)
            total_pages = math.ceil(current_response['content']['page_info']['total_records'] / PAGE_SIZE)
            page_number = page_number + 1
            print("### PROCESSING PAGE ### " + str(page_number))
            response.append("Ingested 1500, on page " + str(page_number) + " out of " + str(total_pages) + " pages.")
    except Exception as e:
        print("########## ISSUE LOOPING")
        print(e)
    return response
        
        

def usgs_data_pull(page_number):
    #Send mock data first
    usgs_data = requests.get('https://pubs.er.usgs.gov/pubs-services/publication/?page_size=' + str(PAGE_SIZE) + "&page_number=" + str(page_number), timeout=120, headers=headers)
    payload_for_unified_search = { "documents": []}
    documents_sent_to_upload = 0
    failed_uploads = 0
    usgs_content = json.loads(usgs_data.content)
    for record in usgs_content.get("records"):
        try:
            date_object = {
                'date': record.get("displayToPublicDate"),
                'title': "Published"
            }
            parsed_description = re.sub(r'<.*?>', '', record.get("docAbstract"))
            parsed_title = re.sub(r'<.*?>', '', record.get("title"))
            if "contributors" not in record:
                continue
            lead_author = retreive_lead_author(record)
            if lead_author is None:
                continue
            lead_author_name = lead_author.get('family') + ', ' + lead_author.get('given')
            co_authors = retreive_co_authors(record)
            if "publicationSubtype" in record:
                subtype = record.get("publicationSubtype").get("text")
            else:
                subtype = ""
            if "doi" in record:
                doi_split = record["doi"].split("/")
                doi_parts = {
                    "organization": doi_split[0],
                    "record": doi_split[1]
                }
            else:
                doi_parts = None
            record_for_unified_search = {
                "title": parsed_title, 
                "description": parsed_description or "", 
                "record_type": record.get("publicationType").get("text") or "", 
                "id": record.get('id'), 
                "source": 'USGS',
                "subtype": subtype,
                "organization": "USGS",
                "doi": record.get("doi") or "",
                "doi_parts": doi_parts,
                "lead": lead_author_name,
                "lead_keyword": lead_author_name,
                "date": date_object,
                "co_authors_keyword": co_authors,
                "co_authors": co_authors,
                "url": "https://pubs.er.usgs.gov/publication/" + str(record["id"])
            }
            payload_for_unified_search['documents'].append(record_for_unified_search)
            documents_sent_to_upload = documents_sent_to_upload + 1
        except Exception as e:
            print("### FAILED RECORD")
            print(record)
            print(e)
            failed_uploads = failed_uploads + 1
    response = upload_data_to_opensearch(payload_for_unified_search)
    combined_response = {
      "content": {
        "failed_uploads": failed_uploads,
        "success": documents_sent_to_upload,
        "response": response.content,
        "page_info": {
            "current_page": usgs_content.get("pageNumber"),
            "total_records":usgs_content.get("recordCount"),
        }
      }
    }
    return combined_response

    
def retreive_lead_author(record):
    lead_author = None
    contributors = record.get("contributors")
    authors = contributors.get("authors") or contributors.get("editors") or []
    if len(authors) > 0:
        if "given" in authors[0] and "family" in authors[0]:
            lead_author = authors[0]
    return lead_author
    
def retreive_co_authors(record):
    co_authors = []
    contributors = record.get("contributors")
    authors = contributors.get("authors") or contributors.get("editors") or []
    for author in authors:
        if "given" in author and "family" in author:
            co_authors.append(author["family"] + ", " + author["given"])
    return co_authors

def upload_data_to_opensearch(json_request):
    auth_headers = {'content-type': 'application/json', 'x-api-key': X_API_KEY, 'Accept': 'application/json'}
    r = requests.put(API_ENDPOINT, headers=auth_headers, timeout=120, json=json_request)
    return r